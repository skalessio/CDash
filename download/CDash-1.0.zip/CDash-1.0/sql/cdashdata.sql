-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 15, 2007 at 12:31 PM
-- Server version: 4.1.9
-- PHP Version: 4.3.10
-- 
-- Database: `cdash`
-- 

-- 
-- Dumping data for table `user`
-- 

INSERT INTO `user` VALUES (1, 'admin@cdash.org', '200ceb26807d6bf99fd6f4f0d1ca54d4', 'administrator', '','Kitware Inc.', 1);
