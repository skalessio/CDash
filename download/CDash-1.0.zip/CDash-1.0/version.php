<?php
/*=========================================================================

  Program:   CDash - Cross-Platform Dashboard System
  Module:    $Id: version.php 899 2008-05-04 00:31:35Z jjomier $
  Language:  PHP
  Date:      $Date: 2008-05-03 20:31:35 -0400 (Sat, 03 May 2008) $
  Version:   $Revision: 899 $

  Copyright (c) 2002 Kitware, Inc.  All rights reserved.
  See Copyright.txt or http://www.cmake.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even 
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
// Hostname of the MySQL database 
$CDASH_VERSION_MAJOR = '1';
$CDASH_VERSION_MINOR = '0';
$CDASH_VERSION_PATCH = '0';
$CDASH_VERSION = $CDASH_VERSION_MAJOR.".".$CDASH_VERSION_MINOR.".".$CDASH_VERSION_PATCH;
?>
