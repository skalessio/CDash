<?php
/*=========================================================================

  Program:   CDash - Cross-Platform Dashboard System
  Module:    $RCSfile: config.php,v $
  Language:  PHP
  Date:      $Date: 2008-03-24 13:49:15 -0400 (Mon, 24 Mar 2008) $
  Version:   $Revision: 759 $

  Copyright (c) 2002 Kitware, Inc.  All rights reserved.
  See Copyright.txt or http://www.cmake.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even 
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
// Hostname of the MySQL database 
$CDASH_VERSION_MAJOR = '0';
$CDASH_VERSION_MINOR = '8';
$CDASH_VERSION_PATCH = '0';
$CDASH_VERSION = $CDASH_VERSION_MAJOR.".".$CDASH_VERSION_MINOR.".".$CDASH_VERSION_PATCH;
?>
