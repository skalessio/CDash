#include <iostream>

/** Main function */
int main(int argc, char* argv[])
{
  double test = 2.3;
  int t = test; // Warning
  std::cout << "Running Test1" << std::endl;
  return 0;
}
