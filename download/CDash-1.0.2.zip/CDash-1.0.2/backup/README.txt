This directory hosts the XML file received from CTest.
You can change this directory in your config file thru the $CDASH_BACKUP_DIRECTORY variable.
You can also change the timeframe of the backups thus $CDASH_BACKUP_TIMEFRAME (in hours), meaning that files older
than the time frame will be automatically deleted.