<?php
/*=========================================================================

  Program:   CDash - Cross-Platform Dashboard System
  Module:    $Id: version.php 990 2008-06-22 21:45:39Z jjomier $
  Language:  PHP
  Date:      $Date: 2008-06-22 17:45:39 -0400 (Sun, 22 Jun 2008) $
  Version:   $Revision: 990 $

  Copyright (c) 2002 Kitware, Inc.  All rights reserved.
  See Copyright.txt or http://www.cmake.org/HTML/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even 
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
// Current version 
$CDASH_VERSION_MAJOR = '1';
$CDASH_VERSION_MINOR = '0';
$CDASH_VERSION_PATCH = '2';
$CDASH_VERSION = $CDASH_VERSION_MAJOR.".".$CDASH_VERSION_MINOR.".".$CDASH_VERSION_PATCH;
?>
